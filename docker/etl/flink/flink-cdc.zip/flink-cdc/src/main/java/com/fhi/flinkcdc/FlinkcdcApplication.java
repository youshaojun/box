package com.fhi.flinkcdc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlinkcdcApplication {

    public static void main(String[] args) {
        SpringApplication.run(FlinkcdcApplication.class, args);
    }

}
